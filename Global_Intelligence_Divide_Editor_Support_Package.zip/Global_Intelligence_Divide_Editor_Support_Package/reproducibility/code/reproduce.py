"""Reconstructed verification pipeline, not the original research code.
Run from any directory: python code/reproduce.py. Inputs are immutable.
"""
from pathlib import Path
import json, hashlib, warnings
import numpy as np
import pandas as pd
import ols as sm
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.metrics import silhouette_score, adjusted_rand_score
from sklearn.decomposition import PCA
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True)
INPUT=ROOT/'inputs'; DER=ROOT/'derived';DER.mkdir(exist_ok=True)
w=pd.ExcelFile(next(INPUT.glob('*stage9*.xlsx')))
frames={s:pd.read_excel(w,s).dropna(how='all') for s in w.sheet_names}
for s,d in frames.items():d.to_csv(DER/(s+'.csv'),index=False)
checks=[]
def check(name,actual,expected,tol=1e-8):
 a=np.asarray(actual,dtype=float);e=np.asarray(expected,dtype=float)
 delta=float(np.nanmax(np.abs(a-e)))
 checks.append(dict(check=name,max_absolute_difference=delta,tolerance=tol,passed=bool(delta<=tol)))
def mm(x):return 100*(x-x.min())/(x.max()-x.min())
def gini(x):
 x=np.sort(np.asarray(x,float)); n=len(x)
 return float(2*np.dot(np.arange(1,n+1),x)/(n*x.sum())-(n+1)/n)
s3=frames['Master_Stage3'].set_index('ISO3'); pre=frames['Preliminary_Scores'].set_index('ISO3');s7=frames['Stage7_Final_AICS'].set_index('ISO3');s8=frames['Stage8_IEC_AEC_CIG_ACCE'].set_index('ISO3')
sk=s3[['S1_WIPO_Score','S2_WIPO_Score','S3_WIPO_Score']].apply(pd.to_numeric,errors='coerce');skills=sk.mean(axis=1).where(sk.notna().sum(axis=1)>=2)
check('Skills from observed WIPO scores',skills.loc[skills.notna()],s8.loc[skills.notna(),'Skills'])
hpc=mm(np.log1p(s3.TOP500_Rmax_TFlops));check('HPC log min max',hpc,s8.Compute_HPC)
data=s3[['Oxford_Governance','Oxford_AI_Infrastructure','Oxford_Resilience']].mean(axis=1);check('Data Oxford proxy',data.dropna(),s8.loc[data.notna(),'Data'])
pop=s3.Population_thousands/1000
s4=frames['Stage4_AI_Scores'].set_index('ISO3');s5=frames['Stage5_AI_Scores'].set_index('ISO3');a3=frames['A3_Private_AI_Investment'].set_index('ISO3')
a1=mm(np.log1p(s4.A1_AI_Publications_per_million));a2=mm(np.log1p(s5.A2_Patents_Granted/pop));a3score=mm(np.log1p(a3['Private AI Investment']/pop))
for label,calc,col in [('A1',a1,'A1_Research_Score'),('A2',a2,'A2_Patent_Score'),('A3',a3score,'A3_Score_0_100')]:check(label+' log intensity min max',calc.dropna(),s7.loc[calc.notna(),col])
aics=pd.concat([a1,a2,a3score,s3.Oxford_Development_Diffusion],axis=1).mean(axis=1,skipna=False)
check('AICS equal mean',aics.dropna(),s7.loc[aics.notna(),'AICS_Final_4Component'])
d=pd.DataFrame({'Economy':s3.Economy,'Region':s7.Region,'Income':s7.Income,'Connectivity':s3.Internet_Users_pct,'Compute_HPC':hpc,'Data':data,'Skills':skills,'AICS':aics})
d['AEC']=d[['Compute_HPC','Data','Skills']].mean(axis=1,skipna=False);d['IEC']=d[['Connectivity','Compute_HPC','Data','Skills']].mean(axis=1,skipna=False)
for col in ['AEC','IEC']:check(col,d.loc[d[col].notna(),col],s8.loc[d[col].notna(),col])
predictors=['Connectivity','Compute_HPC','Data','Skills'];matched=d.dropna(subset=predictors+['AICS']);ai=d.dropna(subset=['AICS']);cig=d.dropna(subset=['Connectivity','AICS'])
m59=sm.OLS(cig.AICS,sm.add_constant(cig.Connectivity)).fit();m1=sm.OLS(matched.AICS,sm.add_constant(matched.Connectivity)).fit();m2=sm.OLS(matched.AICS,sm.add_constant(matched[predictors])).fit()
d.loc[cig.index,'CIG_Residual']=m59.resid;d.loc[matched.index,'ACCE_Residual']=m2.resid
matched=d.loc[matched.index].copy();ai=d.loc[ai.index].copy()
check('CIG residuals',m59.resid,s8.loc[cig.index,'CIG_Residual']);check('ACCE residuals',m2.resid,s8.loc[matched.index,'ACCE_Residual'])
z=(matched[predictors+['AICS']]-matched[predictors+['AICS']].mean())/matched[predictors+['AICS']].std(ddof=0)
std=sm.OLS(z.AICS,sm.add_constant(z[predictors])).fit(); ref=frames['Stage9_Standardized_OLS']['Std. Beta'].iloc[:5]
check('Standardized beta',std.params,ref)
stats=[]
for sample,frame in [('available',d),('matched58',matched)]:
 for col in predictors+['AEC','IEC','AICS']:
  v=frame[col].dropna();stats.append(dict(sample=sample,variable=col,N=len(v),mean=v.mean(),sd=v.std(ddof=1),CV=v.std(ddof=1)/v.mean(),Gini=gini(v)))
pd.DataFrame(stats).to_csv(OUT/'inequality.csv',index=False)
for col in ['Connectivity','IEC','AICS']:
 r=frames['Stage8_Paired_Inequality'].set_index('Measure').loc[col];v=matched[col];check('Matched '+col+' inequality',[v.mean(),v.std(ddof=1),v.std(ddof=1)/v.mean(),gini(v)],r[['Mean','Std. dev.','CV','Gini']])
check('Model R squared',[m59.rsquared,m1.rsquared,m2.rsquared],[0.287998855311262,0.2905150776355534,0.8112907635669747])
ci=std.conf_int();pd.DataFrame({'beta':std.params,'SE':std.bse,'t':std.tvalues,'p':std.pvalues,'CI_low':ci[0],'CI_high':ci[1]}).to_csv(OUT/'standardized_ols.csv')
f,p,df=m2.compare_f_test(m1)
models={'CIG59':{'N':len(cig),'R2':m59.rsquared},'M1matched58':{'N':len(matched),'R2':m1.rsquared},'M2matched58':{'N':len(matched),'R2':m2.rsquared,'incremental_F':f,'incremental_p':p}}
(OUT/'models.json').write_text(json.dumps(models,indent=2))
rng=np.random.default_rng(20261005);boot=[]
for _ in range(5000):
 q=matched.iloc[rng.integers(0,len(matched),len(matched))];boot.append([gini(q.AICS)-gini(q.Connectivity),q.AICS.std(ddof=1)/q.AICS.mean()-q.Connectivity.std(ddof=1)/q.Connectivity.mean()])
(OUT/'bootstrap.json').write_text(json.dumps({'seed':20261005,'resamples':5000,'Gini_difference_CI':np.quantile(np.array(boot)[:,0],[.025,.975]).tolist(),'CV_difference_CI':np.quantile(np.array(boot)[:,1],[.025,.975]).tolist(),'note':'Original bootstrap seed is absent; this is an independent verification, not an exact recreation of stored endpoints.'},indent=2))
eta=[]
for group in ['Region','Income']:
 for col in ['Connectivity','AICS']:
  v=matched[col];between=sum(len(g)*(g[col].mean()-v.mean())**2 for _,g in matched.groupby(group));eta.append({'group':group,'outcome':col,'eta_squared':between/((v-v.mean())**2).sum()})
 for sample,frame in [('aics59',ai),('complete58',matched)]:
  frame.groupby(group)[['Connectivity','IEC','AICS','CIG_Residual','ACCE_Residual']].agg(['count','mean','std']).to_csv(OUT/(group+'_'+sample+'.csv'))
pd.DataFrame(eta).to_csv(OUT/'eta_squared.csv',index=False)
balance=1-(matched[['Compute_HPC','Data','Skills']].max(axis=1)-matched[['Compute_HPC','Data','Skills']].min(axis=1))/100
b=pd.DataFrame({'AEC':matched.AEC,'Balance':balance,'AICS':matched.AICS});b=(b-b.mean())/b.std(ddof=0);h5=sm.OLS(b.AICS,sm.add_constant(b[['AEC','Balance']])).fit();check('H5 coefficients',h5.params.iloc[1:],frames['Stage9_H5_Balance']['Std. Beta'].iloc[:2]);h5.summary2().tables[1].to_csv(OUT/'H5_balance.csv')
X=StandardScaler().fit_transform(matched[predictors+['AICS']]);diag=[]
for k in range(2,7):
 km=KMeans(n_clusters=k,n_init=50,random_state=20261005).fit(X);ward=AgglomerativeClustering(n_clusters=k,linkage='ward').fit_predict(X);diag.append({'k':k,'silhouette':silhouette_score(X,km.labels_),'inertia':km.inertia_,'Ward_ARI':adjusted_rand_score(km.labels_,ward)})
km=KMeans(n_clusters=4,n_init=50,random_state=20261005).fit(X);labels=pd.Series(km.labels_,index=matched.index,name='reconstructed_cluster');matched.join(labels).to_csv(OUT/'clusters_reconstructed.csv');pd.DataFrame(diag).to_csv(OUT/'cluster_diagnostics_reconstructed.csv',index=False)
# Additional diagnostics and descriptive pair comparison.
from itertools import combinations
pairs=[]
for a,b in combinations(matched.index,2):
 cg=abs(matched.loc[a,'Connectivity']-matched.loc[b,'Connectivity']);ag=abs(matched.loc[a,'AICS']-matched.loc[b,'AICS'])
 if cg<=5 and ag>=15:pairs.append({'ISO3_A':a,'ISO3_B':b,'Connectivity_gap':cg,'AICS_gap':ag,'AEC_gap':abs(matched.loc[a,'AEC']-matched.loc[b,'AEC'])})
pd.DataFrame(pairs).sort_values('AICS_gap',ascending=False).to_csv(OUT/'matched_country_pairs.csv',index=False)
vif=[]
for col in predictors:
 other=[c for c in predictors if c!=col];r=sm.OLS(z[col],sm.add_constant(z[other])).fit().rsquared;vif.append({'variable':col,'VIF':1/(1-r)})
pd.DataFrame(vif).to_csv(OUT/'VIF.csv',index=False)
pc=PCA(n_components=2).fit_transform(X)
plt.figure(figsize=(7,5));plt.scatter(pc[:,0],pc[:,1],c=km.labels_,cmap='tab10');plt.xlabel('PC1');plt.ylabel('PC2');plt.title('Reconstructed four cluster typology (58 countries)');plt.tight_layout();plt.savefig(OUT/'verified_typology_PCA.png',dpi=200);plt.close()
for group in ['Region','Income']:
 means=ai.groupby(group)[['Connectivity','IEC','AICS']].mean();means.plot.barh(figsize=(8,5));plt.xlabel('Unweighted mean score');plt.title(group+' groups in 59-country AICS sample');plt.tight_layout();plt.savefig(OUT/('verified_'+group+'.png'),dpi=200);plt.close()
q=d.dropna(subset=['CIG_Residual','ACCE_Residual']);plt.figure(figsize=(7,5));plt.scatter(q.CIG_Residual,q.ACCE_Residual);plt.axhline(0,color='gray');plt.axvline(0,color='gray');plt.xlabel('CIG residual');plt.ylabel('ACCE residual');plt.tight_layout();plt.savefig(OUT/'verified_residuals.png',dpi=200);plt.close()
# New verification figures have explicit titles and may differ in style from originals.
plt.figure(figsize=(7,4));plt.bar(['Connectivity','IEC','AICS'],[gini(matched[x]) for x in ['Connectivity','IEC','AICS']]);plt.ylabel('Unweighted Gini');plt.title('Matched 58-country sample');plt.tight_layout();plt.savefig(OUT/'verified_inequality.png',dpi=200);plt.close()
plt.figure(figsize=(7,4));plt.scatter(cig.Connectivity,cig.AICS);xx=np.linspace(cig.Connectivity.min(),100,100);plt.plot(xx,m59.params.iloc[0]+m59.params.iloc[1]*xx);plt.xlabel('Internet users (%)');plt.ylabel('AICS');plt.title('Connectivity and AICS (59 countries)');plt.tight_layout();plt.savefig(OUT/'verified_connectivity_AICS.png',dpi=200);plt.close()
d.to_csv(DER/'analytical_country_data.csv');matched.to_csv(DER/'matched_58.csv');ai.to_csv(DER/'aics_59.csv')
pd.DataFrame(checks).to_csv(OUT/'verification_checks.csv',index=False)
(OUT/'verification_summary.json').write_text(json.dumps({'checks':len(checks),'passed':sum(x['passed'] for x in checks),'failed':[x for x in checks if not x['passed']],'N_core':len(d),'N_AICS':len(ai),'N_matched':len(matched)},indent=2))
print((OUT/'verification_summary.json').read_text())

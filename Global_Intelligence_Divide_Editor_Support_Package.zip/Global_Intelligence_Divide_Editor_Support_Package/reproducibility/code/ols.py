"""Ordinary least squares with classical standard errors using NumPy/SciPy."""
import numpy as np
import pandas as pd
from scipy import stats
class Fit:
 def __init__(self,y,X):
  X=pd.DataFrame(X); y=pd.Series(y);self.n=len(y); self.k=X.shape[1];self.df=self.n-self.k
  a=X.to_numpy(float);b=y.to_numpy(float);coef=np.linalg.lstsq(a,b,rcond=None)[0];res=b-a@coef;self.sse=res@res
  self.params=pd.Series(coef,index=X.columns);self.resid=pd.Series(res,index=y.index);self.rsquared=1-self.sse/((b-b.mean())@(b-b.mean()))
  cov=self.sse/self.df*np.linalg.inv(a.T@a);self.bse=pd.Series(np.sqrt(np.diag(cov)),index=X.columns);self.tvalues=self.params/self.bse;self.pvalues=pd.Series(2*stats.t.sf(abs(self.tvalues),self.df),index=X.columns)
 def conf_int(self):
  q=stats.t.ppf(.975,self.df);return pd.DataFrame({0:self.params-q*self.bse,1:self.params+q*self.bse})
 def compare_f_test(self,small):
  diff=self.k-small.k;f=((small.sse-self.sse)/diff)/(self.sse/self.df);return f,stats.f.sf(f,diff,self.df),diff
 def summary2(self):
  ci=self.conf_int();return type('Summary',(),{'tables':[None,pd.DataFrame({'coef':self.params,'SE':self.bse,'t':self.tvalues,'p':self.pvalues,'CI_low':ci[0],'CI_high':ci[1]})]})()
class OLS:
 def __init__(self,y,X):self.y=y;self.X=X
 def fit(self):return Fit(self.y,self.X)
def add_constant(x):
 x=pd.DataFrame(x).copy();x.insert(0,'const',1.);return x

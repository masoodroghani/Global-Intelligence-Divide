# Global Intelligence Divide reproducibility materials

This package supports technical review of Beyond Connectivity Mapping the Global Intelligence Divide Across Compute Data Skills and AI Capability. It preserves all eight supplied files and provides a reconstructed verification pipeline. It is NOT a complete archive of every original source download.

## Contents
- inputs/: unchanged supplied workbooks manuscript and ZIP packages.
- original_packages/: unpacked original figures typology and regional materials.
- derived/: CSV exports of the stage 9 workbook and reconstructed 139-country analytical data, 59 AICS countries and 58 matched countries.
- code/reproduce.py and code/ols.py: newly reconstructed analysis, clearly distinguished from original code (not supplied).
- outputs/: verification checks, estimates, independent bootstrap, clustering and verification figures.
- documentation/: dictionaries, methods, source inventory, limitations, revision checklist and data availability text.

## Run
Python 3.11 or later with numpy pandas scipy scikit-learn matplotlib openpyxl.
Install dependencies in your own environment with pip install -r code/requirements.txt.
Run python code/reproduce.py from the package folder. The script uses paths relative to itself, never downloads data, never modifies inputs, and writes derived/ and outputs/.
Numerical comparisons use absolute tolerance 1e-8. Bootstrap and k means have fixed reconstruction seed 20261005; the original seeds were not recorded. Regenerating all outputs may take several minutes. The version record reports the environment actually used for this audit.

## Interpretation and submission status
The original workbooks explicitly describe Connectivity Compute and Data as provisional. Read documentation/editor_submission_checklist.txt before submitting. Original raw TOP500 systems, original CSET/ETO publication patent and investment exports, and original World Bank indicator downloads are missing. Selected values survive in intermediate worksheets. These retained data allow numerical verification but do not fully verify original source extraction and filters.
Do not claim that all raw data or original scripts have been supplied. Do not invent missing observations or recreate supposed raw files from manuscript numbers. Confirm redistribution terms from the source providers before public repository release. This package is prepared for supplementary upload; it has not been published to a repository and has no repository DOI.
